module com.mycompany.garageapplication {
    requires javafx.controls;
    exports com.mycompany.surgery;
}
